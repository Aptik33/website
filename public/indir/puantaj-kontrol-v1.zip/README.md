# Puantaj – Bordro Çapraz Kontrol Paketi

Sürüm 1.0.0 · MIT Lisansı

Aynı ay için hazırlanmış puantaj ve bordro dosyalarını satır satır karşılaştırır,
gözden kaçması kolay tutarsızlıkları listeler.

## Kurulum

Harici bağımlılık yok. Python 3.10 veya üzeri yeterli.

```bash
python --version   # 3.10+ olmalı
```

## Hızlı deneme

Paketin içindeki örnek veriyle çalıştır:

```bash
python kontrol.py --puantaj ornek-puantaj.csv --bordro ornek-bordro.csv
```

Örnek veri bilinçli olarak hatalı hazırlandı: 3 hata ve 4 uyarı üretmesi gerekiyor.
Farklı bir sonuç alıyorsan kurulumda bir sorun var demektir.

## Kendi verinle kullanım

Kendi dosyalarını hazırlamak için önce boş şablonları üret:

```bash
python kontrol.py --sablon-olustur
```

Bu komut çalıştığın klasöre `puantaj.csv` ve `bordro.csv` dosyalarını yazar.
Excel'de açıp doldurabilirsin (noktalı virgül ayraçlı, UTF-8).

Bulguları dosyaya almak için:

```bash
python kontrol.py --puantaj puantaj.csv --bordro bordro.csv --rapor bulgular.csv
```

## Beklenen sütunlar

`puantaj.csv`

| sütun | açıklama |
|---|---|
| `sicil` | personel sicil/numara, eşleştirme anahtarı |
| `ad_soyad` | ad soyad |
| `calisilan_gun` | ay içinde fiilen çalışılan gün |
| `fazla_mesai_saat` | fazla mesai saati (yoksa 0) |

`bordro.csv`

| sütun | açıklama |
|---|---|
| `sicil` | personel sicil/numara |
| `ad_soyad` | ad soyad |
| `sgk_gun` | bordroda bildirilen SGK gün sayısı |
| `eksik_gun_kodu` | eksik gün kodu (yoksa boş) |
| `brut_ucret` | brüt ücret |
| `fazla_mesai_tutar` | fazla mesai tutarı |
| `net_ucret` | net ücret |

Sütun sırası önemli değil, sütun adları önemli. Sayılarda hem `1.234,56`
hem `1234.56` biçimi kabul edilir.

## Kontrol listesi

| kod | önem | kontrol |
|---|---|---|
| E01 | hata | Puantajda var, bordroda yok |
| E02 | hata | Bordroda var, puantajda yok |
| E03 | uyarı | Çalışılan gün ile SGK günü uyuşmuyor |
| E04 | uyarı | SGK günü 30'un altında ama eksik gün kodu boş |
| E05 | uyarı | Fazla mesai saati var, bordroda tutar yok |
| E06 | uyarı | Bordroda fazla mesai tutarı var, puantajda saat yok |
| E07 | hata | Net ücret brütten büyük |
| E08 | hata | SGK günü 0 ama brüt ücret var |
| E09 | hata | Aynı sicil birden fazla satırda |

Çıkış kodu: hata varsa `1`, yoksa `0`. Toplu çalıştırmalarda işe yarar.

## Sınırlar — bunu bilmeden kullanma

- **Mevzuat kontrolü yapmaz.** Asgari ücret, SGK tavanı, vergi dilimi, teşvik
  hesapları bu aracın kapsamında değil. Sadece iki dosya arasındaki tutarlılığa bakar.
- **Eksik gün kodunun doğruluğunu denetlemez.** Kodun dolu olup olmadığına bakar,
  doğru kod olup olmadığına bakmaz.
- **Kıst ücret hesabı yapmaz.** Ay içinde giriş/çıkışı olan personelde E03 uyarısı
  beklenen bir durum olabilir; bunu değerlendirmek sana kalır.
- **Karar vermez.** Ürettiği her satır "buraya bak" demektir, "burası yanlış" demez.

## Gizlilik

Script tamamen yerel çalışır. Hiçbir veri internete gönderilmez, hiçbir servise
bağlanmaz. Dosyalarını kendi bilgisayarında işler.

## Lisans

MIT. Kullanabilir, değiştirebilir, dağıtabilirsin. Garanti verilmez.
