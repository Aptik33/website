#!/usr/bin/env python3
"""
Puantaj - Bordro capraz kontrol araci
=====================================

Sadece standart kutuphane kullanir; harici bagimlilik yoktur.

Ne yapar
--------
Ayni ay icin hazirlanmis puantaj ve bordro dosyalarini satir satir karsilastirir,
insan gozuyle kacmasi kolay olan tutarsizliklari listeler:

  E01  Puantajda olup bordroda olmayan personel
  E02  Bordroda olup puantajda olmayan personel
  E03  Calisilan gun ile bordrodaki SGK gunu uyusmuyor
  E04  SGK gunu 30'un altinda ama eksik gun kodu bos
  E05  Puantajda fazla mesai saati var, bordroda fazla mesai tutari yok
  E06  Bordroda fazla mesai tutari var, puantajda fazla mesai saati yok
  E07  Net ucret brut ucretten buyuk
  E08  SGK gunu 0 ama brut ucret var
  E09  Ayni personel numarasi birden fazla satirda

Kullanim
--------
  python kontrol.py --puantaj puantaj.csv --bordro bordro.csv
  python kontrol.py --puantaj p.csv --bordro b.csv --rapor bulgular.csv
  python kontrol.py --sablon-olustur          # bos ornek dosyalari uretir

Beklenen sutunlar
-----------------
puantaj.csv : sicil,ad_soyad,calisilan_gun,fazla_mesai_saat
bordro.csv  : sicil,ad_soyad,sgk_gun,eksik_gun_kodu,brut_ucret,fazla_mesai_tutar,net_ucret

Sutun sirasi onemli degildir, basliklarin adi onemlidir.

Lisans: MIT
"""

from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import dataclass
from pathlib import Path

SURUM = "1.0.0"

PUANTAJ_SUTUNLARI = {"sicil", "ad_soyad", "calisilan_gun", "fazla_mesai_saat"}
BORDRO_SUTUNLARI = {
    "sicil",
    "ad_soyad",
    "sgk_gun",
    "eksik_gun_kodu",
    "brut_ucret",
    "fazla_mesai_tutar",
    "net_ucret",
}


@dataclass
class Bulgu:
    kod: str
    sicil: str
    ad_soyad: str
    aciklama: str

    @property
    def onem(self) -> str:
        # E01/E02/E07/E08 dogrudan hata; digerleri kontrol edilmesi gereken uyari.
        return "HATA" if self.kod in {"E01", "E02", "E07", "E08", "E09"} else "UYARI"


def sayi(deger: str | None, varsayilan: float = 0.0) -> float:
    """Turkce ondalik ayraci (virgul) ve binlik noktasini tolere eder."""
    if deger is None:
        return varsayilan
    temiz = deger.strip().replace(" ", "").replace(" ", "")
    if not temiz:
        return varsayilan
    if "," in temiz and "." in temiz:
        temiz = temiz.replace(".", "").replace(",", ".")
    else:
        temiz = temiz.replace(",", ".")
    try:
        return float(temiz)
    except ValueError:
        return varsayilan


def csv_oku(yol: Path, beklenen: set[str]) -> list[dict[str, str]]:
    if not yol.exists():
        sys.exit(f"HATA: dosya bulunamadi -> {yol}")

    # Excel'den cikan CSV'ler cogunlukla UTF-8 BOM'lu veya cp1254 olur.
    for kodlama in ("utf-8-sig", "cp1254", "utf-8"):
        try:
            with yol.open(encoding=kodlama, newline="") as f:
                ornek = f.read(4096)
                f.seek(0)
                try:
                    ayrac = csv.Sniffer().sniff(ornek, delimiters=";,\t").delimiter
                except csv.Error:
                    ayrac = ";"
                satirlar = list(csv.DictReader(f, delimiter=ayrac))
            break
        except UnicodeDecodeError:
            continue
    else:
        sys.exit(f"HATA: dosya kodlamasi cozulemedi -> {yol}")

    if not satirlar:
        sys.exit(f"HATA: dosya bos -> {yol}")

    basliklar = {(b or "").strip().lower() for b in satirlar[0].keys()}
    eksik = beklenen - basliklar
    if eksik:
        sys.exit(f"HATA: {yol.name} dosyasinda eksik sutun(lar): {', '.join(sorted(eksik))}")

    return [{(k or "").strip().lower(): (v or "").strip() for k, v in s.items()} for s in satirlar]


def indeksle(satirlar: list[dict[str, str]], kaynak: str) -> tuple[dict[str, dict], list[Bulgu]]:
    """Sicil numarasina gore sozluge cevirir, tekrar eden sicilleri raporlar."""
    sonuc: dict[str, dict] = {}
    bulgular: list[Bulgu] = []
    for s in satirlar:
        sicil = s.get("sicil", "")
        if not sicil:
            continue
        if sicil in sonuc:
            bulgular.append(
                Bulgu("E09", sicil, s.get("ad_soyad", ""), f"{kaynak} dosyasinda sicil birden fazla kez gecmis")
            )
            continue
        sonuc[sicil] = s
    return sonuc, bulgular


def karsilastir(puantaj: dict[str, dict], bordro: dict[str, dict]) -> list[Bulgu]:
    bulgular: list[Bulgu] = []

    for sicil in sorted(set(puantaj) - set(bordro)):
        p = puantaj[sicil]
        bulgular.append(Bulgu("E01", sicil, p.get("ad_soyad", ""), "Puantajda var, bordroda yok"))

    for sicil in sorted(set(bordro) - set(puantaj)):
        b = bordro[sicil]
        bulgular.append(Bulgu("E02", sicil, b.get("ad_soyad", ""), "Bordroda var, puantajda yok"))

    for sicil in sorted(set(puantaj) & set(bordro)):
        p, b = puantaj[sicil], bordro[sicil]
        ad = b.get("ad_soyad") or p.get("ad_soyad", "")

        calisilan = sayi(p.get("calisilan_gun"))
        sgk_gun = sayi(b.get("sgk_gun"))
        fm_saat = sayi(p.get("fazla_mesai_saat"))
        fm_tutar = sayi(b.get("fazla_mesai_tutar"))
        brut = sayi(b.get("brut_ucret"))
        net = sayi(b.get("net_ucret"))
        eksik_kod = b.get("eksik_gun_kodu", "").strip()

        if abs(calisilan - sgk_gun) > 0.001:
            bulgular.append(
                Bulgu("E03", sicil, ad, f"Puantaj {calisilan:g} gun, bordro SGK {sgk_gun:g} gun")
            )

        if sgk_gun < 30 and not eksik_kod:
            bulgular.append(Bulgu("E04", sicil, ad, f"SGK gunu {sgk_gun:g} ama eksik gun kodu bos"))

        if fm_saat > 0 and fm_tutar == 0:
            bulgular.append(Bulgu("E05", sicil, ad, f"{fm_saat:g} saat fazla mesai var, bordroda tutar yok"))

        if fm_tutar > 0 and fm_saat == 0:
            bulgular.append(Bulgu("E06", sicil, ad, f"Bordroda {fm_tutar:,.2f} TL fazla mesai var, puantajda saat yok"))

        if net > brut and brut > 0:
            bulgular.append(Bulgu("E07", sicil, ad, f"Net {net:,.2f} > Brut {brut:,.2f}"))

        if sgk_gun == 0 and brut > 0:
            bulgular.append(Bulgu("E08", sicil, ad, f"SGK gunu 0 ama brut ucret {brut:,.2f} TL"))

    return bulgular


def yazdir(bulgular: list[Bulgu], toplam_personel: int) -> None:
    print()
    print(f"Puantaj-Bordro capraz kontrol  v{SURUM}")
    print("=" * 64)
    print(f"Karsilastirilan personel : {toplam_personel}")
    print(f"Bulgu sayisi             : {len(bulgular)}")
    print("=" * 64)

    if not bulgular:
        print("Tutarsizlik bulunamadi.")
        print()
        print("NOT: Bu arac yalnizca listelenen kontrolleri yapar. Temiz cikmasi")
        print("     bordronun mevzuata uygun oldugu anlamina gelmez.")
        return

    print()
    print(f"{'ONEM':<6} {'KOD':<5} {'SICIL':<10} {'AD SOYAD':<24} ACIKLAMA")
    print("-" * 100)
    for b in sorted(bulgular, key=lambda x: (x.onem != "HATA", x.kod, x.sicil)):
        print(f"{b.onem:<6} {b.kod:<5} {b.sicil:<10} {b.ad_soyad[:23]:<24} {b.aciklama}")

    hata = sum(1 for b in bulgular if b.onem == "HATA")
    uyari = len(bulgular) - hata
    print("-" * 100)
    print(f"{hata} hata, {uyari} uyari.")
    print()
    print("NOT: Bu arac karar vermez, kontrol eder. Her bulguyu kendin dogrula.")


def rapor_yaz(bulgular: list[Bulgu], yol: Path) -> None:
    with yol.open("w", encoding="utf-8-sig", newline="") as f:
        y = csv.writer(f, delimiter=";")
        y.writerow(["onem", "kod", "sicil", "ad_soyad", "aciklama"])
        for b in bulgular:
            y.writerow([b.onem, b.kod, b.sicil, b.ad_soyad, b.aciklama])
    print(f"Rapor yazildi -> {yol}")


def sablon_olustur() -> None:
    p = Path("puantaj.csv")
    b = Path("bordro.csv")
    with p.open("w", encoding="utf-8-sig", newline="") as f:
        y = csv.writer(f, delimiter=";")
        y.writerow(["sicil", "ad_soyad", "calisilan_gun", "fazla_mesai_saat"])
        y.writerow(["1001", "Ornek Personel", "30", "0"])
    with b.open("w", encoding="utf-8-sig", newline="") as f:
        y = csv.writer(f, delimiter=";")
        y.writerow(
            ["sicil", "ad_soyad", "sgk_gun", "eksik_gun_kodu", "brut_ucret", "fazla_mesai_tutar", "net_ucret"]
        )
        y.writerow(["1001", "Ornek Personel", "30", "", "30000,00", "0,00", "24500,00"])
    print(f"Sablonlar olusturuldu: {p} ve {b}")
    print("Excel'de acip kendi verinle doldurabilirsin (CSV, noktali virgul ayracli).")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Puantaj ve bordro dosyalarini capraz kontrol eder.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--puantaj", type=Path, help="puantaj.csv yolu")
    ap.add_argument("--bordro", type=Path, help="bordro.csv yolu")
    ap.add_argument("--rapor", type=Path, help="bulgularin yazilacagi CSV yolu")
    ap.add_argument("--sablon-olustur", action="store_true", help="bos ornek dosyalar uretir")
    ap.add_argument("--version", action="version", version=f"kontrol.py {SURUM}")
    a = ap.parse_args()

    if a.sablon_olustur:
        sablon_olustur()
        return 0

    if not a.puantaj or not a.bordro:
        ap.print_help()
        return 2

    puantaj_satir = csv_oku(a.puantaj, PUANTAJ_SUTUNLARI)
    bordro_satir = csv_oku(a.bordro, BORDRO_SUTUNLARI)

    puantaj, b1 = indeksle(puantaj_satir, "Puantaj")
    bordro, b2 = indeksle(bordro_satir, "Bordro")

    bulgular = b1 + b2 + karsilastir(puantaj, bordro)
    yazdir(bulgular, len(set(puantaj) | set(bordro)))

    if a.rapor:
        rapor_yaz(bulgular, a.rapor)

    # CI veya toplu calistirma icin: hata varsa 1 doner.
    return 1 if any(b.onem == "HATA" for b in bulgular) else 0


if __name__ == "__main__":
    raise SystemExit(main())
